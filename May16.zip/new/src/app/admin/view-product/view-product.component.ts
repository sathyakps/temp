import { Component, OnInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { MatDialog } from '@angular/material';
import { ConfirmationDialogComponent } from 'src/app/admin/confirmation-dialog/confirmation-dialog.component';
import { ProductService } from '../../@core/services/product.service';
import { DataService } from '../../@core/services/data.service';
import { AddProductComponent } from '../add-product/add-product.component';


@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss']
})
export class ViewProductComponent {
    userData = {};
    allProducts = [];
    settings =
    {
        actions: false,
        columns: {
         name: {
            title: 'Name',
          },
          price: {
            title: 'Price',
          },
          brand: {
            title: 'Brand',
          },
          maximumDiscount: {
            title: 'Discount',
          },
          description: {
            title: 'Description',
          }
        },
         attr: {
            class: 'table table-bordered',
          },
          noDataMessage: 'No Products Found',
          pager: {
              perPage: 9
          },
          mode: 'external'
      }

      source: LocalDataSource = new LocalDataSource();
      constructor(public dialog: MatDialog, private productService: ProductService, private dataService: DataService) {
            this.dataService.loggedInUser.subscribe(data => {
                if (data) {
                    this.userData = data;
                    this.getProductDetail();
                }
            });
      }

      getProductDetail() {
          this.productService.getProductOfAdmin(this.userData['email']).subscribe(data => {
            if (data['success']) {
                this.allProducts = data['data'];
                this.source.load(this.allProducts);
              }
          });
      }
      onDeleteConfirm(event) {
        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
            width: '400px',
            data: {
                name: 'Product',
                text: "Deleting will remove the product and all its details. This action can't be reversed",
                action: 'Delete'
            },
        });

      }
      onSaveConfirm(event) {
        if (window.confirm('Are you sure you want to save?')) {
          event.newData['name'] += ' + added in code';
          event.confirm.resolve(event.newData);
        } else {
          event.confirm.reject();
        }
      }
      onCreateConfirm(event) {
        if (window.confirm('Are you sure you want to create?')) {
          event.newData['name'] += ' + added in code';
          event.confirm.resolve(event.newData);
        } else {
          event.confirm.reject();
        }
      }
      addProduct() {
        const dialogRef = this.dialog.open(AddProductComponent, {
            width : "600px",
            height : "400px",
            data : this.userData
        });

        dialogRef.componentInstance.sentBackData.subscribe(data => {
            if (data) {
                this.allProducts.push(data);
                this.source.load(this.allProducts);
            }
        });
      }
}
