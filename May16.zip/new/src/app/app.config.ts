// export const BASR_URL = 'http://localhost:3000/';
export const BASR_URL = 'https://shoppyzone.herokuapp.com/';
